package Ticket;


public class DashBoard {
    
public void DisplayTotalTickets(){
}
public void DisplayNewTickets(){
}
public void DisplaySolvedTickets(){
}
public void DisplayClosedTickets(){
}
public void DisplayOpenedTickets(){
}
public void DisplayUnAnsweredTickets(){
}
}