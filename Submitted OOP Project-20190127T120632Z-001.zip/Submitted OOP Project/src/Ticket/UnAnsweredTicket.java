package Ticket;


import ticketingsystem.Date;

public class UnAnsweredTicket extends Date {
protected Date DueDate;


    public Date getDueDate() {
        return DueDate;
    }

    public void setDueDate(Date DueDate) {
        this.DueDate = DueDate;
    }

public void UnAnsweredTicket(){
    
}}
