package Ticket;

import ticketingsystem.Date;

public class SolvedTicket {
protected Date TimeTakenToBeSolved;

    public Date getTimeTakenToBeSolved() {
        return TimeTakenToBeSolved;
    }

    public void setTimeTakenToBeSolved(Date TimeTakenToBeSolved) {
        this.TimeTakenToBeSolved = TimeTakenToBeSolved;
    }
public void SolvedTickets(){
}

}
