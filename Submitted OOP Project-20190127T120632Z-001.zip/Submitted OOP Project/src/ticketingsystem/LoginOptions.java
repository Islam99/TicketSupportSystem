package ticketingsystem;

public interface LoginOptions {
public boolean LoginIn(String UN , String Password);
public void Logout();
}
