
package ticketingsystem;
public interface CRUD {
    void Create();
    void Read();
    void Update();
    void Delete();
    void Search();
}